<?php
// pages/get_arsip_inactive.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

$auth = new Auth();
$auth->requireAdmin();

header('Content-Type: application/json');

$db = new Database();
$conn = $db->getConnection();

$response = ['status' => 'error', 'message' => 'Terjadi kesalahan tidak dikenal.'];

try {
    $stmt = $conn->prepare("SELECT * FROM arsip_inactive ORDER BY id DESC");
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $response = ['status' => 'success', 'data' => $data];

} catch (PDOException $e) {
    $response = ['status' => 'error', 'message' => 'Gagal mengambil data arsip inactive: ' . $e->getMessage(), 'error' => $e->getMessage()];
}

echo json_encode($response);
?>
```php
<?php
// pages/get_arsip_inactive_by_id.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

$auth = new Auth();
$auth->requireAdmin();

header('Content-Type: application/json');

$db = new Database();
$conn = $db->getConnection();

$response = ['status' => 'error', 'message' => 'Terjadi kesalahan tidak dikenal.'];

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        $stmt = $conn->prepare("SELECT * FROM arsip_inactive WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($data) {
            $response = ['status' => 'success', 'data' => $data];
        } else {
            $response = ['status' => 'error', 'message' => 'Arsip inactive tidak ditemukan.'];
        }

    } catch (PDOException $e) {
        $response = ['status' => 'error', 'message' => 'Gagal mengambil data arsip inactive: ' . $e->getMessage(), 'error' => $e->getMessage()];
    }
} else {
    $response = ['status' => 'error', 'message' => 'ID arsip inactive tidak disediakan.'];
}

echo json_encode($response);
?>
```php
<?php
// pages/add_arsip_inactive.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

$auth = new Auth();
$auth->requireAdmin();

header('Content-Type: application/json');

$db = new Database();
$conn = $db->getConnection();

$response = ['status' => 'error', 'message' => 'Terjadi kesalahan tidak dikenal.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nomor_surat = $_POST['nomor_surat'] ?? '';
    $berita_acara_surat = $_POST['berita_acara_surat'] ?? '';
    $status = $_POST['status'] ?? 'inaktif'; // Default for inactive
    $tahun_dibuat = $_POST['tahun_dibuat'] ?? null;
    $gambar_surat_file = null;

    // Handle file upload
    if (isset($_FILES['gambar_surat']) && $_FILES['gambar_surat']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads/arsip_inactive/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $fileName = uniqid() . '_' . basename($_FILES['gambar_surat']['name']);
        $targetFilePath = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['gambar_surat']['tmp_name'], $targetFilePath)) {
            $gambar_surat_file = $fileName;
        } else {
            $response = ['status' => 'error', 'message' => 'Gagal mengunggah gambar/surat.'];
            echo json_encode($response);
            exit();
        }
    }

    try {
        $stmt = $conn->prepare("INSERT INTO arsip_inactive (nomor_surat, berita_acara_surat, gambar_surat, status, tahun_dibuat) VALUES (:nomor_surat, :berita_acara_surat, :gambar_surat, :status, :tahun_dibuat)");
        $stmt->bindParam(':nomor_surat', $nomor_surat);
        $stmt->bindParam(':berita_acara_surat', $berita_acara_surat);
        $stmt->bindParam(':gambar_surat', $gambar_surat_file);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':tahun_dibuat', $tahun_dibuat, PDO::PARAM_INT);

        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => 'Arsip inactive berhasil ditambahkan.'];
        } else {
            $response = ['status' => 'error', 'message' => 'Gagal menambahkan arsip inactive.'];
        }

    } catch (PDOException $e) {
        $response = ['status' => 'error', 'message' => 'Kesalahan database: ' . $e->getMessage(), 'error' => $e->getMessage()];
    }
} else {
    $response = ['status' => 'error', 'message' => 'Metode permintaan tidak valid.'];
}

echo json_encode($response);
?>
```php
<?php
// pages/update_arsip_inactive.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

$auth = new Auth();
$auth->requireAdmin();

header('Content-Type: application/json');

$db = new Database();
$conn = $db->getConnection();

$response = ['status' => 'error', 'message' => 'Terjadi kesalahan tidak dikenal.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $nomor_surat = $_POST['nomor_surat'] ?? '';
    $berita_acara_surat = $_POST['berita_acara_surat'] ?? '';
    $status = $_POST['status'] ?? 'inaktif';
    $tahun_dibuat = $_POST['tahun_dibuat'] ?? null;
    $gambar_surat_file = null;

    if (!$id) {
        $response = ['status' => 'error', 'message' => 'ID arsip inactive tidak disediakan.'];
        echo json_encode($response);
        exit();
    }

    // Get existing file name
    $stmt = $conn->prepare("SELECT gambar_surat FROM arsip_inactive WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $existing_gambar_surat = $stmt->fetchColumn();
    $gambar_surat_file = $existing_gambar_surat; // Keep existing if no new file uploaded

    // Handle file upload
    if (isset($_FILES['gambar_surat']) && $_FILES['gambar_surat']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads/arsip_inactive/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $fileName = uniqid() . '_' . basename($_FILES['gambar_surat']['name']);
        $targetFilePath = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['gambar_surat']['tmp_name'], $targetFilePath)) {
            $gambar_surat_file = $fileName;
            // Optionally, delete old file if it exists
            if ($existing_gambar_surat && file_exists($uploadDir . $existing_gambar_surat)) {
                unlink($uploadDir . $existing_gambar_surat);
            }
        } else {
            $response = ['status' => 'error', 'message' => 'Gagal mengunggah gambar/surat baru.'];
            echo json_encode($response);
            exit();
        }
    }

    try {
        $stmt = $conn->prepare("UPDATE arsip_inactive SET nomor_surat = :nomor_surat, berita_acara_surat = :berita_acara_surat, gambar_surat = :gambar_surat, status = :status, tahun_dibuat = :tahun_dibuat WHERE id = :id");
        $stmt->bindParam(':nomor_surat', $nomor_surat);
        $stmt->bindParam(':berita_acara_surat', $berita_acara_surat);
        $stmt->bindParam(':gambar_surat', $gambar_surat_file);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':tahun_dibuat', $tahun_dibuat, PDO::PARAM_INT);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => 'Arsip inactive berhasil diperbarui.'];
        } else {
            $response = ['status' => 'error', 'message' => 'Gagal memperbarui arsip inactive.'];
        }

    } catch (PDOException $e) {
        $response = ['status' => 'error', 'message' => 'Kesalahan database: ' . $e->getMessage(), 'error' => $e->getMessage()];
    }
} else {
    $response = ['status' => 'error', 'message' => 'Metode permintaan tidak valid.'];
}

echo json_encode($response);
?>
```php
<?php
// pages/delete_arsip_inactive.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

$auth = new Auth();
$auth->requireAdmin();

header('Content-Type: application/json');

$db = new Database();
$conn = $db->getConnection();

$response = ['status' => 'error', 'message' => 'Terjadi kesalahan tidak dikenal.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = $input['id'] ?? null;

    if (!$id) {
        $response = ['status' => 'error', 'message' => 'ID arsip inactive tidak disediakan.'];
        echo json_encode($response);
        exit();
    }

    try {
        // Get file name to delete from server
        $stmt = $conn->prepare("SELECT gambar_surat FROM arsip_inactive WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $gambar_surat_to_delete = $stmt->fetchColumn();

        $stmt = $conn->prepare("DELETE FROM arsip_inactive WHERE id = :id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            // Delete the actual file from the server
            if ($gambar_surat_to_delete && file_exists(__DIR__ . '/../uploads/arsip_inactive/' . $gambar_surat_to_delete)) {
                unlink(__DIR__ . '/../uploads/arsip_inactive/' . $gambar_surat_to_delete);
            }
            $response = ['status' => 'success', 'message' => 'Arsip inactive berhasil dihapus.'];
        } else {
            $response = ['status' => 'error', 'message' => 'Gagal menghapus arsip inactive.'];
        }

    } catch (PDOException $e) {
        $response = ['status' => 'error', 'message' => 'Kesalahan database: ' . $e->getMessage(), 'error' => $e->getMessage()];
    }
} else {
    $response = ['status' => 'error', 'message' => 'Metode permintaan tidak valid.'];
}

echo json_encode($response);
?>
```php
<?php
// pages/delete_old_inactive_arsip.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

$auth = new Auth();
$auth->requireAdmin();

header('Content-Type: application/json');

$db = new Database();
$conn = $db->getConnection();

$response = ['status' => 'error', 'message' => 'Terjadi kesalahan tidak dikenal.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Define a threshold year for "old" archives (e.g., older than 5 years ago)
    $currentYear = date('Y');
    $thresholdYear = $currentYear - 5; // Example: delete archives older than 5 years

    try {
        // Get list of files to delete before deleting records
        $stmt = $conn->prepare("SELECT gambar_surat FROM arsip_inactive WHERE tahun_dibuat < :threshold_year");
        $stmt->bindParam(':threshold_year', $thresholdYear, PDO::PARAM_INT);
        $stmt->execute();
        $files_to_delete = $stmt->fetchAll(PDO::FETCH_COLUMN);

        $stmt = $conn->prepare("DELETE FROM arsip_inactive WHERE tahun_dibuat < :threshold_year");
        $stmt->bindParam(':threshold_year', $thresholdYear, PDO::PARAM_INT);

        if ($stmt->execute()) {
            $deleted_count = $stmt->rowCount();
            // Delete actual files from the server
            $uploadDir = __DIR__ . '/../uploads/arsip_inactive/';
            foreach ($files_to_delete as $file) {
                if ($file && file_exists($uploadDir . $file)) {
                    unlink($uploadDir . $file);
                }
            }
            $response = ['status' => 'success', 'message' => "Berhasil menghapus {$deleted_count} arsip inactive lama (dibuat sebelum tahun {$thresholdYear})."];
        } else {
            $response = ['status' => 'error', 'message' => 'Gagal menghapus arsip inactive lama.'];
        }

    } catch (PDOException $e) {
        $response = ['status' => 'error', 'message' => 'Kesalahan database: ' . $e->getMessage(), 'error' => $e->getMessage()];
    }
} else {
    $response = ['status' => 'error', 'message' => 'Metode permintaan tidak valid.'];
}

echo json_encode($response);
?>
