<?php
// get_documents.php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$auth = new Auth();
$auth->requireLogin();

try {
    $db = new Database();
    $conn = $db->getConnection();

    $user_id = $_SESSION['user_id'] ?? null;

    if (empty($user_id)) {
        echo json_encode(['status' => 'error', 'message' => 'User ID tidak ditemukan. Harap login ulang.']);
        exit;
    }

    $stmt = $conn->prepare("
        SELECT
            d.id,
            d.user_id,
            d.original_name as file_name, -- UBAH INI
            d.file_path,
            d.file_type,
            d.file_size,
            d.created_at,
            u.username as owner_username,
            u.full_name as owner_full_name
        FROM documents d
        JOIN users u ON d.user_id = u.id
        WHERE d.user_id = :user_id
        ORDER BY d.created_at DESC
    ");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $documents = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'status' => 'success',
        'documents' => $documents
    ]);

} catch (Exception $e) {
    error_log("Error getting documents: " . $e->getMessage());
    echo json_encode([
        'status' => 'error',
        'message' => 'Gagal mengambil data dokumen',
        'error' => $e->getMessage()
    ]);
}
?>