<?php
// upload_document.php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$auth = new Auth();
$auth->requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = new Database();
    $conn = $db->getConnection();

    $user_id = $_SESSION['user_id'] ?? null;

    if (empty($user_id)) {
        echo json_encode(['status' => 'error', 'message' => 'User ID tidak ditemukan. Harap login ulang.']);
        exit;
    }

    if (!isset($_FILES['document']) || $_FILES['document']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['status' => 'error', 'message' => 'Gagal mengunggah file. Kode error: ' . ($_FILES['document']['error'] ?? 'N/A')]);
        exit;
    }

    $file = $_FILES['document'];
    $originalFileName = basename($file['name']); // Ini adalah nama file asli dari user
    $fileType = $file['type'];
    $fileSize = $file['size'];
    $fileTempName = $file['tmp_name'];

    $uploadDir = __DIR__ . '/../uploads/documents/';
    
    // Pastikan nama file unik untuk disimpan di server (stored_name)
    $storedFileName = uniqid() . '_' . time() . '.' . pathinfo($originalFileName, PATHINFO_EXTENSION);
    $filePath = $uploadDir . $storedFileName;

    // Pastikan folder ini ada dan bisa ditulis (izin sudah diperiksa sebelumnya)
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0775, true); // Buat folder jika belum ada
    }

    if (move_uploaded_file($fileTempName, $filePath)) {
        try {
            // UBAH NAMA KOLOM DI KUESRI INSERT INI
            $query = "INSERT INTO documents (user_id, original_name, stored_name, file_path, file_type, file_size) VALUES (:user_id, :original_name, :stored_name, :file_path, :file_type, :file_size)";
            $stmt = $conn->prepare($query);

            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':original_name', $originalFileName); // Nama asli
            $stmt->bindParam(':stored_name', $storedFileName);     // Nama unik di server
            $stmt->bindParam(':file_path', $filePath);             // Path lengkap di server
            $stmt->bindParam(':file_type', $fileType);
            $stmt->bindParam(':file_size', $fileSize);

            if ($stmt->execute()) {
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Dokumen berhasil diunggah dan disimpan.',
                    'document' => [
                        'id' => $conn->lastInsertId(),
                        'file_name' => $originalFileName, // Kirimkan nama asli ke frontend
                        'file_type' => $fileType,
                        'file_size' => $fileSize,
                        'upload_date' => date('Y-m-d H:i:s'), // Tanggal saat ini
                        'file_path' => $filePath // Kirimkan path untuk debugging/referensi
                    ]
                ]);
            } else {
                unlink($filePath);
                echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan info dokumen ke database.']);
            }
        } catch (PDOException $e) {
            unlink($filePath);
            error_log("Error saving document to DB: " . $e->getMessage());
            echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan database saat mengunggah dokumen.', 'error' => $e->getMessage()]);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Gagal memindahkan file yang diunggah. Periksa izin folder.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Metode request tidak diizinkan.']);
}
?>